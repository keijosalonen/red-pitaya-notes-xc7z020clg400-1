#! /bin/sh

killall -q mcpha-server
killall -q pha-server
